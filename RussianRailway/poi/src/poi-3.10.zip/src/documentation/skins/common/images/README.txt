This directory is currently useless, as the sitemap only looks in
skins/{forrest:skin}, so files must be kept in synch manually until this is
fixed.
